package Sub ;

use Super ;
@ISA = qw( Super ) ;
 

sub new {
  my $class = shift ;
  my $self = {}; 
  bless ( $self , $class ) ;
  $self -> {'caller'} = shift ; 
  return $self 
}

sub doit {
   my $self = shift                        ;
   use Data::Dumper                        ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller()                   ;
 f $text_co      ;
   #my $caller = caller